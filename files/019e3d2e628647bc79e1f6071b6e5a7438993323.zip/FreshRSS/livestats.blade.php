<ul class="livestats">
    @if ($unread > 0)
        <li>
            <span class="title" style="color:orange;">{!! $unread !!} Unread</span>
        </li>
    @endif
</ul>
