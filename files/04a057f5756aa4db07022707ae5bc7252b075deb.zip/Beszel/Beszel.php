<?php

namespace App\SupportedApps\Beszel;

class Beszel extends \App\SupportedApps
{
}
