<?php

namespace App\SupportedApps\Rspamd;

class Rspamd extends \App\SupportedApps
{
}
