<ul class="livestats">
    <li><span class="title">Leech: {{ $leech_count }}</span><strong>{!! $download_rate !!}</strong></li>
    <li><span class="title">Seed: {{ $seed_count }}</span><strong>{!! $upload_rate !!}</strong></li>
</ul>
