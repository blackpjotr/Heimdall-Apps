<ul class="livestats">
    <li>
        <span class="title">Uptime</span>
        <strong>{!! $uptime !!}</strong>
    </li>
    <li>
        <span class="title">Alerts</span>
        <strong>{!! $alert_tot !!}</strong>
    </li>
</ul>
