<ul class="livestats">
    <li>
        <span class="title">Repos</span>
        <strong>{!! $repositories !!}</strong>
    </li>
    <li>
        <span class="title">Organizations</span>
        <strong>{!! $organizations !!}</strong>
    </li>
</ul>
