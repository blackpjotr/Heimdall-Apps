<?php

namespace App\SupportedApps\Cronicle;

class Cronicle extends \App\SupportedApps
{
}
