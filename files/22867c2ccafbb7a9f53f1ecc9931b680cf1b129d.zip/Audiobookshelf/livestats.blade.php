<ul class="livestats">
    <li>
        <span class="title">Playtime</span>
        <strong>{!! $totalTime !!}</strong>
    </li>
    <li>
        <span class="title"># Books</span>
        <strong>{!! $bookCount !!}</strong>
    </li>
</ul>
