<?php

namespace App\SupportedApps\Nightscout;

class Nightscout extends \App\SupportedApps
{
}
