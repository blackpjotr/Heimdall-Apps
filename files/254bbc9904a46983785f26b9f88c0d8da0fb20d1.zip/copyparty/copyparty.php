<?php

namespace App\SupportedApps\copyparty;

class copyparty extends \App\SupportedApps // phpcs:ignore
{
}
