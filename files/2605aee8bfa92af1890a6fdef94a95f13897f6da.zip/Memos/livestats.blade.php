<ul class="livestats">
    <li>
        <span class="title">Memos</span>
        <strong>{!! $memo_count !!}</strong>
    </li>
</ul>