<?php

namespace App\SupportedApps\Browserless;

class Browserless extends \App\SupportedApps
{
}
