<ul class="livestats">
    <li>
        <span class="title">Bookmarks</span>
        <strong>{!! $bookmarks_count !!}</strong>
    </li>
</ul>