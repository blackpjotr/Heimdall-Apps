<ul class="livestats">
    <li>
        <span class="title">Total Apps</span>
        <strong>{!! $total !!}</strong>
    </li>
    <li>
        <span class="title">Active Apps</span>
        <strong>{!! $active !!}</strong>
    </li>
</ul>