<?php

namespace App\SupportedApps\BrotherPrinter;

class BrotherPrinter extends \App\SupportedApps
{
}
