<?php

namespace App\SupportedApps\ScratchMap;

class ScratchMap extends \App\SupportedApps
{
}
