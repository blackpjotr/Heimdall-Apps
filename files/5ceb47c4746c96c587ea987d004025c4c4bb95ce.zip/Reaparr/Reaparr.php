<?php

namespace App\SupportedApps\Reaparr;

class Reaparr extends \App\SupportedApps
{
}
