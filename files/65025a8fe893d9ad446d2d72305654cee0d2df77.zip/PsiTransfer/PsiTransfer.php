<?php

namespace App\SupportedApps\PsiTransfer;

class PsiTransfer extends \App\SupportedApps
{
}
