<?php

namespace App\SupportedApps\YNAB;

class YNAB extends \App\SupportedApps
{
}
