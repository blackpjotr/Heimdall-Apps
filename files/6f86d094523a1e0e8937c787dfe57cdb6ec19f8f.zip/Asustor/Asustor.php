<?php

namespace App\SupportedApps\Asustor;

class Asustor extends \App\SupportedApps
{
}
