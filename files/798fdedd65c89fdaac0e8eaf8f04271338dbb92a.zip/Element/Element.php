<?php

namespace App\SupportedApps\Element;

class Element extends \App\SupportedApps
{
}
