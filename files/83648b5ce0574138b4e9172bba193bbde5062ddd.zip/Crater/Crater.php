<?php

namespace App\SupportedApps\Crater;

class Crater extends \App\SupportedApps
{
}
