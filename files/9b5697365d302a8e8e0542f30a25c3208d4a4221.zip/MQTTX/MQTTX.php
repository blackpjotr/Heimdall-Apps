<?php

namespace App\SupportedApps\MQTTX;

class MQTTX extends \App\SupportedApps
{
}
