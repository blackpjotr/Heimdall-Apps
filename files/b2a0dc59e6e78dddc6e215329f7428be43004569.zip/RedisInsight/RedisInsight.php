<?php

namespace App\SupportedApps\RedisInsight;

class RedisInsight extends \App\SupportedApps
{
}
