<?php

namespace App\SupportedApps\EmbyStat;

class EmbyStat extends \App\SupportedApps
{
}
