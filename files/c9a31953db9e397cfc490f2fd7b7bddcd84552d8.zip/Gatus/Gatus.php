<?php

namespace App\SupportedApps\Gatus;

class Gatus extends \App\SupportedApps
{
}
