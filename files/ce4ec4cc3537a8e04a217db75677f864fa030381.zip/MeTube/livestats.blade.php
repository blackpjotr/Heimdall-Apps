<ul class="livestats">
    <li>
        <span class="title">Queue</span>
        <strong>{!! $queue_size !!}</strong>
    </li>
    <li>
        <span class="title">Done</span>
        <strong>{!! $done_size !!}</strong>
    </li>
</ul>