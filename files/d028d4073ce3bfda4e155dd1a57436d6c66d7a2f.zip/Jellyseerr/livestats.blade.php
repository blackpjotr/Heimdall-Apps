<ul class="livestats">
    <li>
        <span class="title">Requests</span>
        <strong>{!! $requests !!}</strong>
    </li>
    <li>
        <span class="title">Issues</span>
        <strong>{!! $issues !!}</strong>
    </li>
</ul>
