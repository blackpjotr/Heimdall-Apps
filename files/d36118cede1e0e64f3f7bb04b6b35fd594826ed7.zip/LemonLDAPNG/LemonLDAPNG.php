<?php

namespace App\SupportedApps\LemonLDAPNG;

class LemonLDAPNG extends \App\SupportedApps
{
}
