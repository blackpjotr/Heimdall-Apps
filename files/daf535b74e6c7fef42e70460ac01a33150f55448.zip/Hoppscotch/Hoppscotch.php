<?php

namespace App\SupportedApps\Hoppscotch;

class Hoppscotch extends \App\SupportedApps
{
}
