<?php

namespace App\SupportedApps\YOURLS;

class YOURLS extends \App\SupportedApps
{
}
