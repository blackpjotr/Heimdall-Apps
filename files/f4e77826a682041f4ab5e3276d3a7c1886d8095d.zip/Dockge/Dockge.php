<?php

namespace App\SupportedApps\Dockge;

class Dockge extends \App\SupportedApps
{
}
